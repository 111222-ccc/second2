package cn.edu.sicnu.cs.stu.qxl.second

class ProgramAdviserModel {
    fun getAdvice(): String {
        return "You can choose computer science major!"
    }
}
