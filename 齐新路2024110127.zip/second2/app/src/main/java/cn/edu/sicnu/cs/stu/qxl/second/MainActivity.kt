package cn.edu.sicnu.cs.stu.qxl.second

import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import cn.edu.sicnu.cs.stu.qxl.second.databinding.Layout2Binding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: Layout2Binding
    private var count = 1
    private val adviserModel = ProgramAdviserModel()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = Layout2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener {
            val tv = TextView(this)
            val content = getString(R.string.new_tv_text, count)
            tv.text = content
            tv.textSize = 18f
            binding.llShow.addView(tv)
            count++
            scrollToBottom()
        }
        binding.button2.setOnClickListener {
            val resFromModel = adviserModel.getAdvice()
            val showStr = getString(R.string.advise_result, resFromModel)
            binding.tvResult.text = showStr
        }
    }
    private fun scrollToBottom() {
        val parentView = binding.llShow.parent
        if (parentView is ScrollView) {
            parentView.post {
                parentView.fullScroll(android.view.View.FOCUS_DOWN)
            }
        }
    }
}
